<?php

class randomUserSaver {

    public function __construct() {
        if (!empty($_GET) && !empty($_GET['ready'])) {
            // Whatever
        }

        if (!empty($_POST)) {
            $link = mysql_connect('localhost', 'root', '');
            mysql_select_db('randomuser', $link) or die('Could not select database.');

            $users = $_POST['results'];
            
            foreach ($users as $user) {
                $sqlQuery = "INSERT INTO `userdata` (`user_gender`,`name_title`,`name_first`,`name_last`,`location_street`,`location_city`,`location_state`,
                    `location_zip`,`spec_email`,`spec_password`,`spec_md5_hash`,`spec_sha1_hash`,`user_phone`,`user_cell`,`user_ssn`,`user_picture`,`user_seed`) 
                    VALUES (
                        '" . $user['user']['gender'] . "', 
                        '" . $user['user']['name']['title'] . "', 
                        '" . $user['user']['name']['first'] . "', 
                        '" . $user['user']['name']['last'] . "', 
                        '" . $user['user']['location']['street'] . "', 
                        '" . $user['user']['location']['city'] . "', 
                        '" . $user['user']['location']['state'] . "', 
                        '" . $user['user']['location']['zip'] . "', 
                        '" . $user['user']['email'] . "', 
                        '" . $user['user']['password'] . "', 
                        '" . $user['user']['md5 hash'] . "', 
                        '" . $user['user']['sha1 hash'] . "', 
                        '" . $user['user']['phone'] . "', 
                        '" . $user['user']['cell'] . "', 
                        '" . $user['user']['SSN'] . "', 
                        '" . $user['user']['picture'] . "', 
                        '" . $user['seed'] . "'
                    )";

                mysql_query($sqlQuery) or die(mysql_error());                
            }
            echo json_encode(array('status' => 'success'));die();
        }
    }

}

$raussa = new randomUserSaver;
?>
<html>
    <head>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
        <?php
        if (!empty($_GET) && !empty($_GET['ready'])) {
            ?><script src="ajaxRequestToRandomUser.js"></script><?php
        }
        ?>
    </head>
    <body>
        <pre>
What's to save in DB:
<blockquote style='background-color:#d3d3d3'>
{
  results: [{
    user: {
      gender: "female",
      name: {
        title: "mrs",
        first: "sandra",
        last: "jenkins"
      },
      location: {
        street: "7159 edwards rd",
        city: "seymour",
        state: "pennsylvania",
        zip: "37284"
      },
        email: "sandra.jenkins42@example.com",
        password: "godfather",
        md5 hash: "15d628391f0eb58d7724041ab9a12ae2",
        sha1 hash: "58be9e2c7f22cd75d7af3c9e175b6465b280d61d",
        phone: "(471)-543-4073",
        cell: "(651)-308-4754",
        SSN: "160-76-1677",
        picture: "http://randomuser.me/g/portraits/women/17.jpg"
      },
      seed: "goldenMouse"
    }]
}
</blockquote>
        </pre>

        <a href="?ready=true">Click here, if u r ready.</a> We try to save 1000 Tuples in Database!
    </body>
</html>