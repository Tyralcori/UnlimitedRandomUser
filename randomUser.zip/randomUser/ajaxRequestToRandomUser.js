$(document).ready(function() {
    startLogging();
});

function startLogging() {
    $.ajax({
        url: 'http://randomuser.me/g/?results=5',
        dataType: 'json',
        success: function(user) {
            $.ajax({
                url: '?addUser=true',
                dataType: 'json',
                method: 'POST',
                data: user,
                success: function(answer) {
                    console.log(answer.status);
                    if (answer.status == 'success') {
                        startLogging();
                    }
                }
            });
        }
    });
}